package com.witvpn.ikev2.presentation.utils;

public class Constants {
    public static final int[] chartUpload = new int[]{5, 30, 100, 65, 80};
    public static final int[] chartDownload = new int[]{5, 30, 65, 50, 100};
}
