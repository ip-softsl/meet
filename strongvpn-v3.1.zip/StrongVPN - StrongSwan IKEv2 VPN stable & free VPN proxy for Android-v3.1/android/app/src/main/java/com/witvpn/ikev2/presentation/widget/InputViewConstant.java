package com.witvpn.ikev2.presentation.widget;

import com.witvpn.ikev2.R;

public class InputViewConstant {
    public static int[] STATE_ERROR = new int[]{R.attr.state_error};
}
