package org.strongswan.android.utils.traffic

enum class TrafficType {
    MOBILE,
    ALL
}